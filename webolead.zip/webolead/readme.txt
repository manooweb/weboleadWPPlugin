=== WebOLead ===
Contributors: manooweb
Tags: WebOLead, Call to action form
Tested up to: 4.5.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Official WebOLead script installation for WordPress.

== Description ==

This is the official plugin for simply installing WebOLead script on your website.

== Installation ==

1. Upload the webolead folder to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the WebOLead plugin through the 'Plugins' screen in WordPress
1. Configure the plugin by going to the `WebOLead` menu that appears in your admin menu

== Changelog ==

= 1.0.0 =
* First release
